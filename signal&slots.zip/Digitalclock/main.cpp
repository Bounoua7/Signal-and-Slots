#include "digitalclock.h"

#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    auto D = new digitalclock;
    D-> show();
    return a.exec();
}
