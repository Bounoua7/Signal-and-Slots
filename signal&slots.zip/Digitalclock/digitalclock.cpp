#include "digitalclock.h"
#include<QHBoxLayout>
#include<QLayout>
#include<QTime>
digitalclock::digitalclock(QWidget *parent):QWidget(parent)
{
   createWidgets();
   placeWidgets();
   updateTime();
   startTimer(1000);
}
void digitalclock::createWidgets()
{
    hour= new QLCDNumber;
    hour->setDigitCount(2);
    minute=new QLCDNumber;
    minute->setDigitCount(2);
    second=new QLCDNumber;
    second->setDigitCount(2);

}
 void digitalclock::placeWidgets()
 {
     QLayout*layout = new QHBoxLayout;
     setLayout(layout);

     layout->addWidget(hour);
     layout->addWidget(minute);
     layout->addWidget(second);


 }
 void digitalclock::timerEvent(QTimerEvent *e)
 {
     updateTime();
 }

 void digitalclock::updateTime()
 {
     //obtenir le temps actuel

     auto T = QTime::currentTime();

     //update each lcd
     hour->display(T.hour());
     minute->display(T.minute());
     second->display(T.second());


 }
