#ifndef DIGITALCLOCK_H
#define DIGITALCLOCK_H

#include<QWidget>
#include<QLCDNumber>
#include<QTimerEvent>



class digitalclock : public QWidget
{
    Q_OBJECT

public:
   explicit digitalclock(QWidget *parent = nullptr);


protected:
    void createWidgets();
    void placeWidgets();
    void updateTime();
    void timerEvent(QTimerEvent *e) override;
private:
    QLCDNumber *hour;
    QLCDNumber *minute;
    QLCDNumber *second;
};
#endif // DIGITALCLOCK_H

